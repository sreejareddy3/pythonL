k=input("Enter a string:")
print(k+" Good morningyuo")
string="this is   string with double spaces"
print(string)
print(string.replace("  "," "))
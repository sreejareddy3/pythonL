class Train:
    def __init__(self,name,fare,seats):
        self.name=name
        self.fare=fare
        self.seats=seats
    def getStatus(self):
        print(f"the name of the train is {self.name}")
        print(f"the no.seats available in the train are {len(self.seats)}")
        print(f"Seats:{self.seats}")
    def fareInfo(self):
        print(f"The price of the train is Rs.{self.fare}")
    def bookTicket(self,seatno):
        if(len(self.seats)>0):
            if seatno in self.seats:
                print(f"Your ticket has been booked your seatnumber is {seatno}")
            self.seats.remove(seatno)
        else:
            print("Sorry this train is booked")
    def cancelTicket(self,seatno):
        if seatno not in self.seats:
            self.seats.append(seatno)
            print("Your Ticket cancelled")
intercity=Train("Intercity Express:14015",90,[12,13,14,15,16])
a=1
while(a!=5):
    print("1.Get status\n2.Fair Info\n3.Book Ticket\n4.Cancel Ticket\n5.Exit")
    a=int(input())
    if a==1:
        intercity.getStatus()
    if a==2:
        intercity.fareInfo()   
    if a==3:
        b=int(input("Enter seat number:"))
        intercity.bookTicket(b)
    if a==4:
        b=int(input("Enter booked seat number"))
        intercity.cancelTicket(b)
    if a==5:
        break
print("Thank you for using our service")

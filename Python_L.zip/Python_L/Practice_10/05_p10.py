class Train:
    def __init__(self,name,fare,seats):
        self.name=name
        self.fare=fare
        self.seats=seats
    def getStatus(self):
        print(f"the name of the train is {self.name}")
        print(f"the seats available in the train are {self.seats}")
    def fareInfo(self):
        print(f"The price of the train is Rs.{self.fare}")
    def bookTicket(self):
        if(self.seats>0):
            print(f"Your ticket has been booked your seatnumber is {self.seats}")
            self.seats=self.seats-1
        else:
            print("Sorry this train is booked")

intercity=Train("Intercity Express:14015",90,20)
intercity.getStatus()
intercity.fareInfo()   
intercity.bookTicket()
intercity.getStatus()
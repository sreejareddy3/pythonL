class Number:
    def sum(self):
        return self.a+self.b
num=Number()
num.a=112
num.b=4
s=num.sum()
print(s)
from playsound import playsound
playsound('D:\\Python_L\\Practice_1\\play.mp3')
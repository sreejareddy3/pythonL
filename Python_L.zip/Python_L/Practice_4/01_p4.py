L1=[]
print("Enter the fruits")
i=0
while i<7:
    a=input()
    L1.append(a)
    i=i+1
print(L1)
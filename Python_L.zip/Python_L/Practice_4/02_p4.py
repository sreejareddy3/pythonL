L1=[]
print("Enter the marks")
i=0
while i<6:
    a=int(input())
    L1.append(a)
    i=i+1
L1.sort()
print(L1)
a="567"
print(type(a))
b=int(a)
print(type(b))
print(b+5)
print(a+'gg')
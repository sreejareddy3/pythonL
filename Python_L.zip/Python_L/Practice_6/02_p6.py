m1=int(input())
m2=int(input())
m3=int(input())
t=(float)(m1+m2+m3)/3
if((m1>35 and m2>35 and m3>35) and t>40):
    print("Pass")
else:
    print("Fail")

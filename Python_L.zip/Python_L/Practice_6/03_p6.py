cmnt=input()
if("make alot of money" in cmnt):
    spam=True
elif("buy now" in cmnt):
    spam=True
elif("subscribe this" in cmnt):
    spam=True
elif("click this" in cmnt):
    spam=True
else:
    spam=False
if(spam):
    print("Spam detected")
else:
    print("Spam not detected")
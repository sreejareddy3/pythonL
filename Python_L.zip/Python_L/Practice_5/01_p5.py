Dict={"kya":"what",
      "kaise":"how",
      "dabba":"box"}
print(Dict.keys())
print("Enter word")
a=input()
print(Dict.get(a))
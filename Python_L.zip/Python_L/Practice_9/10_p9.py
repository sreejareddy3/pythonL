with open('D:\\Python_L\\Practice_9\\book.txt','w') as f:
    f.write("")
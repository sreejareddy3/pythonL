for i in range(1,21):
     with open(f"D:\\Python_L\\Practice_9\\tables\\Multiplication_of_{i}",'w') as f:
            for j in range(1,21):
                f.write(f"{i}X{j}={i*j}")
                if j!=20:
                    f.write("\n")


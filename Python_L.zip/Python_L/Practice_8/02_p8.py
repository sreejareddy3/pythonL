def con(cel):
    return ((cel*(9/7)+32))
n=int(input("enter temperature:"))
fa=con(n)
print("Temperature in farenheit:",fa)

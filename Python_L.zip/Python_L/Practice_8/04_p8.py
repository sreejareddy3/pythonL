def su(n):
    if n==1:
        return 1
    else:
        return n+su(n-1)
num=int(input("enter the number:"))
k=su(num)
print(k)
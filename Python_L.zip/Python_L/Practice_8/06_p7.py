def con(num):
    return (num*2.54)
n=int(input("enter inches:"))
fa=con(n)
print("In CMS:",fa)
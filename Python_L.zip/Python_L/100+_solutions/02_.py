a=int(input("Enter a number"))
i=1
while a>0:
    i=i*a
    a=a-1
print(i)

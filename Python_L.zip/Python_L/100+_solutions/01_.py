l=[]
i=2000
while i<3200:
    if(i%7==0):
        if(i%5!=0):
            l.append(i)
    i=i+1
print(l)
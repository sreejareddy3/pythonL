lst1=[]
c=50
h=30
lst=[x for x in input().split(',')]
for d in lst:
    b=int(((2*c*int(d))/h)**0.5)
    b=str(b)
    lst1.append(b)
print(','.join(lst1))

dict={}
i=int(input("Enter a number:"))
for i in range (1,i+1):
    dict.update({i:i*i})
print(dict)
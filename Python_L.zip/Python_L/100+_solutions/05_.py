class sample:
    def __init__(self):
        self.string=""
    def getString(self):
        self.string=input("Enter String:")
    def putString(self):
        print(f"The string is {self.string.upper()}")
obj=sample()
obj.getString()
obj.putString()
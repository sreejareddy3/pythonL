l=[]
for i in range(1,7):
    a=input("Enter number")
    l.append(a)
print(l)
t=tuple(l)
print(t)
